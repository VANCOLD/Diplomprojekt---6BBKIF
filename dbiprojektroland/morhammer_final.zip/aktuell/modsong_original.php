<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Musik Center   - Lied ändern/löschen</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/dashboard.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>
  
  

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Music Center</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="about_us.html">About US </a></li>
			<li><a href="#"></a></li>
          </ul>
          <form class="navbar-form navbar-right" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="get">
		<!--	<input type="text" name="searchfield" class="form-control" placeholder="Search...">      -->   <!-- von mir auskommentiert -->
			<input type="hidden" name="do" value="insert">      <!--          von mir hinzugefügt         -->
		  </form>
        </div>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
			<li><a href="index.php">Übersicht</a></li>
			<li><a href="upload.html">Upload</a></li>
            <li><a href="Download.html">Download</a></li>
			<li><a href="addalbum.php">Album manuell hinzufügen</a></li>
            <li class="active"><a href="#">Lied ändern/löschen<span class="sr-only">(current)</span></a></li>
          </ul>
        </div>
      </div>
    </div>

	<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Lied ändern/löschen</h1>
    </div>                                                                 <!--                                      -->
	
	<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
	
	
	
<?php 
	if ( isset($_REQUEST["do"]) && $_REQUEST["do"] == "insert" )
	{
		if (isset($_REQUEST["CHECK66"])) //wenn lied gelöscht werden soll
		{
			$con = new mysqli("localhost", "root", "", "music_center_test"); //datenbankverbindung initialisieren
			if ($con->connect_error)
			{ 
				echo "Fehler bei der Verbindung mit der Datenbank: " . mysqli_connect_error();
				exit();
			}
		
			$qstring = "SELECT IdAlbum FROM album WHERE Albumtitel='" . $_REQUEST["Album"] . "';"; //albumid feststellen
			$qresult = $con->query($qstring);
			if ($qres = $qresult->fetch_array())
			{
				$albumid = $qres['IdAlbum'];
			}
			else
			{
				echo "FEHLER: Album existiert nicht!";
				$con->close();
				exit();
			}
			
			$qstring = "SELECT IdLied FROM songs WHERE Liedname='" . $_REQUEST["Liedname"] . "' AND LiedalbumId=" . $albumid . ";"; //liedid feststellen
			$qresult = $con->query($qstring);
			if ($qres = $qresult->fetch_array())
			{
				$liedid = $qres['IdLied'];
			}
			else
			{
				echo "FEHLER: Lied-Album-Kombination existiert nicht!";
				$con->close();
				exit();
			}	
			$qstring = "DELETE FROM songs WHERE IdLied=" . $liedid . ";";
			if (!$con->query($qstring)) echo "Error: " . $qstring . "<br>" . $con->error; //lied aus datenbank löschen
			else echo "Lied " . $_REQUEST["Liedname"] . " erfolgreich von Album " . $_REQUEST["Album"] . " gelöscht!";
			$con->close();
			exit();
		}
		//wenn lied nicht gelöscht, sondern geändert werden soll
		$allfieldsfilled = 1;
		$nothingchanged = 1;
	
		if (isset($_REQUEST["CHECK1"]) && $_REQUEST["Liedgroesseneu"] == "" ) $allfieldsfilled = 0;
		if (isset($_REQUEST["CHECK2"]) && $_REQUEST["Liednameneu"] == "" ) $allfieldsfilled = 0;
		if (isset($_REQUEST["CHECK3"]) && $_REQUEST["Liedlaengeneu"] == "" ) $allfieldsfilled = 0;
		if (isset($_REQUEST["CHECK4"]) && $_REQUEST["Liedformatneu"] == "" ) $allfieldsfilled = 0;
		if (isset($_REQUEST["CHECK5"]) && $_REQUEST["Liedalbumneu"] == "" ) $allfieldsfilled = 0;
		if (isset($_REQUEST["CHECK6"]) && $_REQUEST["Liednummerneu"] == "" ) $allfieldsfilled = 0;
		
		if ($allfieldsfilled == 0) echo "FEHLER: Bitte alle zu ändernden Eingabefelder ausfüllen! <br><br>";
		else
		{
			$con = new mysqli("localhost", "root", "", "music_center_test"); //datenbankverbindung initialisieren
			if ($con->connect_error)
			{ 
				echo "Fehler bei der Verbindung mit der Datenbank: " . mysqli_connect_error();
				exit();
			}
		
			$qstring = "SELECT IdAlbum FROM album WHERE Albumtitel='" . $_REQUEST["Album"] . "';"; //albumid feststellen
			$qresult = $con->query($qstring);
			if ($qres = $qresult->fetch_array())
			{
				$albumid = $qres['IdAlbum'];
			}
			else
			{
				echo "FEHLER: Album existiert nicht!";
				$con->close();
				exit();
			}
			
			$qstring = "SELECT IdLied FROM songs WHERE Liedname='" . $_REQUEST["Liedname"] . "' AND LiedalbumId=" . $albumid . ";"; //liedid feststellen
			$qresult = $con->query($qstring);
			if ($qres = $qresult->fetch_array())
			{
				$liedid = $qres['IdLied'];
			}
			else
			{
				echo "FEHLER: Lied-Album-Kombination existiert nicht!";
				$con->close();
				exit();
			}
			
			if (isset($_REQUEST["CHECK5"])) //wenn neues album eingegeben wurde id des neuen albums feststellen
			{
				$qstring = "SELECT IdAlbum FROM album WHERE Albumtitel='" . $_REQUEST["Liedalbumneu"] . "';"; //albumid feststellen
				$qresult = $con->query($qstring);
				if ($qres = $qresult->fetch_array())
				{
					$albumneuid = $qres['IdAlbum'];
				}
				else
				{
					echo "FEHLER: Neues Album existiert noch nicht!";
					$con->close();
					exit();
				}
			}
			
			
			if (isset($_REQUEST["CHECK1"]))
			{
				$nothingchanged = 0;
				$qstring = "UPDATE songs SET Liedgroesse=" . $_REQUEST["Liedgroesseneu"] . " WHERE IdLied=" . $liedid . ";";
				if (!$con->query($qstring)) echo "Error: " . $qstring . "<br>" . $con->error;
			}
			if (isset($_REQUEST["CHECK2"]))
			{
				$nothingchanged = 0;
				$qstring = "UPDATE songs SET Liedname='" . $_REQUEST["Liednameneu"] . "' WHERE IdLied=" . $liedid . ";";
				if (!$con->query($qstring)) echo "Error: " . $qstring . "<br>" . $con->error;
			}
			if (isset($_REQUEST["CHECK3"]))
			{
				$nothingchanged = 0;
				$qstring = "UPDATE songs SET Liedlaenge=" . $_REQUEST["Liedlaengeneu"] . " WHERE IdLied=" . $liedid . ";";
				if (!$con->query($qstring)) echo "Error: " . $qstring . "<br>" . $con->error;
			}
			if (isset($_REQUEST["CHECK4"]))
			{
				$nothingchanged = 0;
				$qstring = "UPDATE songs SET Liedformat='" . $_REQUEST["Liedformatneu"] . "' WHERE IdLied=" . $liedid . ";";
				if (!$con->query($qstring)) echo "Error: " . $qstring . "<br>" . $con->error;
			}
			if (isset($_REQUEST["CHECK5"]))
			{
				$nothingchanged = 0;
				$qstring = "UPDATE songs SET LiedalbumId=" . $albumneuid . " WHERE IdLied=" . $liedid . ";";
				if (!$con->query($qstring)) echo "Error: " . $qstring . "<br>" . $con->error;
			}
			if (isset($_REQUEST["CHECK6"]))
			{
				$nothingchanged = 0;
				$qstring = "UPDATE songs SET LiedNummer=" . $_REQUEST["Liednummerneu"] . " WHERE IdLied=" . $liedid . ";";
				if (!$con->query($qstring)) echo "Error: " . $qstring . "<br>" . $con->error;
			}

			if (!$nothingchanged)
			{
				echo "Die Änderungen wurden durchgeführt! <br><br>";
			}
			$con->close();
		}
	}
?>

		
	
	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="get">
		<input type="hidden" name="do" value="insert">
		<INPUT TYPE=TEXT NAME="Liedname" SIZE="50" VALUE="Name des Liedes"> <br>
		<INPUT TYPE=TEXT NAME="Album" SIZE="30" VALUE="Album des Liedes"> <br><br>
		LIED LÖSCHEN <INPUT TYPE=CHECKBOX NAME=CHECK66 VALUE=Check66> <br><br>
		Liedgröße ändern <INPUT TYPE=CHECKBOX NAME=CHECK1 VALUE=Check1> auf: <INPUT TYPE=number NAME="Liedgroesseneu" SIZE="11" VALUE=""> Byte<BR>
		Liedname ändern <INPUT TYPE=CHECKBOX NAME=CHECK2 VALUE=Check2> auf: <INPUT TYPE=TEXT NAME="Liednameneu" SIZE="50" VALUE=""><BR>
		Liedlänge ändern <INPUT TYPE=CHECKBOX NAME=CHECK3 VALUE=Check3> auf: <INPUT TYPE=number NAME="Liedlaengeneu" SIZE="11" VALUE=""> Sekunden<BR>
		Liedformat ändern <INPUT TYPE=CHECKBOX NAME=CHECK4 VALUE=Check4> auf: <INPUT TYPE=TEXT NAME="Liedformatneu" SIZE="11" VALUE=""><BR>
		Liedalbum ändern <INPUT TYPE=CHECKBOX NAME=CHECK5 VALUE=Check5> auf: <INPUT TYPE=TEXT NAME="Liedalbumneu" SIZE="30" VALUE=""><BR>
		Liednummer ändern <INPUT TYPE=CHECKBOX NAME=CHECK6 VALUE=Check6> auf: <INPUT TYPE=number NAME="Liednummerneu" SIZE="3" VALUE=""><BR>
		<input type="submit" value="Änderungen durchführen!">
		<!-- <a href="#" id="filldetails" onclick="addFields()">Lieder eingeben/Reset</a> -->
		<div id="container"/>
		<br>
	</form>
	</div>
	
	
	
	
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="js/holder.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
  </html>
