<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Musik Center   - Album manuell hinzufügen</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/dashboard.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
  
  <script type='text/javascript'>
        function addFields(){
            // Number of inputs to create
            var number = document.getElementById("AnzahlLieder").value;
            // Container <div> where dynamic content will be placed
            var container = document.getElementById("container");
            // Clear previous contents of the container
            while (container.hasChildNodes()) {
                container.removeChild(container.lastChild);
            }
            for (i=0;i<number;i++){
                // Append a node with a random text
                container.appendChild(document.createTextNode("Liedname Lied " + (i+1) + ": "));
                // Create an <input> element, set its type and name attributes
                var input = document.createElement("input");
                input.type = "text";
                input.name = "Liedname" + i;
                container.appendChild(input);

				container.appendChild(document.createTextNode("Liednummer: "));
				input = document.createElement("input");
				input.type = "number";
                input.name = "Liednummer" + i;
				container.appendChild(input);				

				container.appendChild(document.createTextNode("Kuenstler: "));
				input = document.createElement("input");
				input.type = "text";
                input.name = "Liedkuenstler" + i;
				container.appendChild(input);
				
				container.appendChild(document.createTextNode("Länge Minuten: "));
				input = document.createElement("input");
				input.type = "number";
                input.name = "Liedminuten" + i;
				container.appendChild(input);
				
				container.appendChild(document.createTextNode("+ Sekunden: "));
				input = document.createElement("input");
				input.type = "number";
                input.name = "Liedsekunden" + i;
				container.appendChild(input);
				
				container.appendChild(document.createTextNode("Liedgröße in Bytes: "));
				input = document.createElement("input");
				input.type = "number";
                input.name = "Liedgroesse" + i;
				container.appendChild(input);				
				
				container.appendChild(document.createTextNode("Liedformat: "));
				input = document.createElement("input");
				input.type = "text";
                input.name = "Liedformat" + i;
				container.appendChild(input);				
				
				
				
				
				// Append a line break 
                container.appendChild(document.createElement("br"));
            }
			container.appendChild(document.createTextNode("In Datenbank eintragen"));
				input = document.createElement("input");
				input.type = "submit";
                input.value = "submit";
				container.appendChild(input);
        }
    </script>
  
  </head>

  <body>
  
  

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Music Center</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="about_us.html">About US </a></li>
			<li><a href="#"></a></li>
          </ul>
          <form class="navbar-form navbar-right" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="get">
		<!--	<input type="text" name="searchfield" class="form-control" placeholder="Search...">      -->   <!-- von mir auskommentiert -->
			<input type="hidden" name="do" value="insert">      <!--          von mir hinzugefügt         -->
		  </form>
        </div>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
			<li><a href="index.php">Übersicht</a></li>
			<li><a href="upload.html">Upload</a></li>
            <li><a href="Download.html">Download</a></li>
            <li class="active"><a href="#">Album manuell hinzufügen <span class="sr-only">(current)</span></a></li>
			<li><a href="modsong.php">Lied ändern/löschen</a></li>
          </ul>
        </div>
      </div>
    </div>

	<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Album hinzufügen</h1>
    </div>                                                                 <!--                                      -->
	
	<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
<?php
	if ( isset($_REQUEST["do"]) && $_REQUEST["do"] == "insert" )
	{
		$arrayindex = "";
		$numberofsongs = $_REQUEST["AnzahlLieder"];
		$allfieldsfilled = 1;
		$liederbereitsvorhanden = 0;
		
		for ($c = 0; $c < $numberofsongs; $c++) //check ob alle felder ausgefüllt wurden
		{
			if ( $_REQUEST["Liedname".$c] == "" ) $allfieldsfilled = 0;
			if ( $_REQUEST["Liednummer".$c] == "" ) $allfieldsfilled = 0;
			if ( $_REQUEST["Liedkuenstler".$c] == "") $allfieldsfilled = 0;
			if ( $_REQUEST["Liedminuten".$c] == "" ) $allfieldsfilled = 0;
			if ( $_REQUEST["Liedsekunden".$c] == "" ) $allfieldsfilled = 0;
			if ( $_REQUEST["Liedgroesse".$c] == "" ) $allfieldsfilled = 0;
			if ( $_REQUEST["Liedformat".$c] == "" ) $allfieldsfilled = 0;
		}
		
		if ($allfieldsfilled == 0) echo "FEHLER: Bitte alle Eingabefelder ausfüllen! <br><br>";
		else
		{
			$con = new mysqli("localhost", "root", "", "music_center_test"); //datenbankverbindung initialisieren
			if ($con->connect_error)
			{ 
				echo "Fehler bei der Verbindung mit der Datenbank: " . mysqli_connect_error();
				exit();
			}
		
			$qstring = "SELECT Kuenstlername FROM kuenstler WHERE Kuenstlername LIKE '" . $_REQUEST["Albumkuenstler"] . "';";
			$qresult = $con->query($qstring);
			if (!$qresult->fetch_array()) //wenn kuenstler noch nicht vorhanden
			{
				$qstring = "INSERT INTO kuenstler (IdKuenstler, Kuenstlername, Realname) VALUES (NULL, '" . $_REQUEST["Albumkuenstler"] . "', NULL);";
				if (!$con->query($qstring)) echo "Error: " . $qstring . "<br>" . $con->error; //kuenstler in kuenstler-tabelle eintragen
			}
			
			$qstring = "SELECT Albumtitel FROM album WHERE Albumtitel LIKE '" . $_REQUEST["Albumname"] . "';";
			$qresult = $con->query($qstring);
			if (!$qresult->fetch_array()) //wenn album noch nicht vorhanden
			{
				$qstring = "INSERT INTO album (IdAlbum, Albumtitel, Erscheinungsjahr) VALUES (NULL, '" . $_REQUEST["Albumname"] . "', '" . $_REQUEST["Erscheinungsjahr"] . "');";
				if (!$con->query($qstring)) echo "Error: " . $qstring . "<br>" . $con->error; //album in album-tabelle eintragen
			}
			
			//checken ob album-kuenstler-kombination bereits vorhanden ist
			$qstring = "SELECT IdAlbum FROM album WHERE Albumtitel LIKE '" . $_REQUEST["Albumname"] . "';"; //albumid feststellen
			$qresult = $con->query($qstring);
			$albumid = $qresult->fetch_array();
			
			$qstring = "SELECT IdKuenstler FROM kuenstler WHERE Kuenstlername LIKE '" . $_REQUEST["Albumkuenstler"] . "';"; // kuenstlerid feststellen
			$qresult = $con->query($qstring);
			$kuenstlerid = $qresult->fetch_array();
			
			$qstring = "SELECT IdAlbumKuenstler FROM `album-kuenstler` WHERE AlbumId LIKE '" . $albumid['IdAlbum'] . "' AND KuenstlerId LIKE '" . $kuenstlerid['IdKuenstler'] . "';";
			$qresult = $con->query($qstring);
			//if(!$qresult) print_r($con->error);
			if (!$qresult->fetch_array()) //wenn album-kuenstler-kombination noch nicht vorhanden
			{
				$qstring = "INSERT INTO `album-kuenstler` (IdAlbumKuenstler, AlbumId, KuenstlerId) VALUES (NULL, '" . $albumid['IdAlbum'] . "', '" . $kuenstlerid['IdKuenstler'] . "');";
				if (!$con->query($qstring)) echo "Error: " . $qstring . "<br>" . $con->error; //album-kuenstler-kombination in album-kuenstler-tabelle eintragen
			}
			
			for ($c = 0; $c < $numberofsongs; $c++) //eingegebene lieder in datenbank eintragen
			{
				//checken ob lied-künstler bereits vorhanden ist
				$qstring = "SELECT Kuenstlername FROM kuenstler WHERE Kuenstlername LIKE '" . $_REQUEST["Liedkuenstler".$c] . "';";
				$qresult = $con->query($qstring);
				if (!$qresult->fetch_array()) //wenn kuenstler noch nicht vorhanden
				{
					$qstring = "INSERT INTO kuenstler (IdKuenstler, Kuenstlername, Realname) VALUES (NULL, '" . $_REQUEST["Liedkuenstler".$c] . "', NULL);";
					if (!$con->query($qstring)) echo "Error: " . $qstring . "<br>" . $con->error; //kuenstler in kuenstler-tabelle eintragen
				}
				
				//checken ob lied für das album bereits vorhanden ist
				$qstring = "SELECT IdLied FROM songs WHERE Liedname LIKE '" . $_REQUEST["Liedname".$c] . "' AND LiedAlbumId LIKE '" . $albumid['IdAlbum'] . "';";
				$qresult = $con->query($qstring);
				if (!$qresult->fetch_array()) //wenn lied für album noch nicht vorhanden
				{
					$qstring = "INSERT INTO songs (IdLied, Liedgroesse, Liedname, Liedlaenge, Liedformat, LiedAlbumId, LiedNummer) VALUES (NULL, '" . $_REQUEST["Liedgroesse".$c] . "', '" . $_REQUEST["Liedname".$c] . "', '" . ($_REQUEST["Liedminuten".$c] * 60 + $_REQUEST["Liedsekunden".$c]) . "', '" . $_REQUEST["Liedformat".$c] . "', '" . $albumid['IdAlbum'] . "', '" . $_REQUEST["Liednummer".$c] . "');";
					if (!$con->query($qstring)) echo "Error: " . $qstring . "<br>" . $con->error; //lied in song-tabelle eintragen
				
					$qstring = "SELECT IdLied FROM songs WHERE Liedname LIKE '" . $_REQUEST["Liedname".$c] . "' AND LiedAlbumId LIKE '" . $albumid['IdAlbum'] . "';"; //liedid feststellen
					$qresult = $con->query($qstring);
					$liedid = $qresult->fetch_array();
		
					$qstring = "SELECT IdKuenstler FROM kuenstler WHERE Kuenstlername LIKE '" . $_REQUEST["Liedkuenstler".$c] . "';"; // kuenstlerid feststellen
					$qresult = $con->query($qstring);
					$liedkuenstlerid = $qresult->fetch_array();
			
					$qstring = "INSERT INTO `kuenstler-songs` (IdKuenstlerSongs, KuenstlerId, LiedId) VALUES (NULL, '" . $liedkuenstlerid['IdKuenstler'] . "', '" . $liedid['IdLied'] . "');";
					if (!$con->query($qstring)) echo "Error: " . $qstring . "<br>" . $con->error; //lied-kuenstler-kombination in kuenstler-songs-tabelle eintragen
				}
				else //wenn lied für album bereits vorhanden
				{
					$liederbereitsvorhanden++;
				}
				
				if ($liederbereitsvorhanden)
				{
					echo $liederbereitsvorhanden . " Lieder waren bereits vorhanden und wurden nicht hinzugefügt.";
				}
				echo "Neue Daten wurden der Datenbank hinzugefügt! <br><br>";
			$con->close();
			}
		}
	}
?>
	
		
	
	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="get">
		<input type="hidden" name="do" value="insert">
		<INPUT TYPE=TEXT NAME="Albumname" SIZE="30" VALUE="Name des Albums"> <br>
		<INPUT TYPE=TEXT NAME="Albumkuenstler" SIZE="30" VALUE="Album ist von Kuenstler..."> <br>
		Erscheinungsjahr: <INPUT TYPE=number NAME="Erscheinungsjahr" SIZE="4" VALUE="1999"><BR> 
		Anzahl an Liedern auf dem Album: <input type="number" id="AnzahlLieder" name="AnzahlLieder" value=""><br />
		<a href="#" id="filldetails" onclick="addFields()">Lieder eingeben/Reset</a>
		<div id="container"/>
		<br>
	</form>
	</div>
	
	
	
	
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="js/holder.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
  </html>
