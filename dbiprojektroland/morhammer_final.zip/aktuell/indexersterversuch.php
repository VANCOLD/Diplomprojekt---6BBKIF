<?php
require(__DIR__.'/../vendor/autoload.php');
	error_reporting(E_ERROR | E_PARSE);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Musik Center   - Übersicht</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/dashboard.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>
  
  

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Music Center</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="about_us.html">About US </a></li>
			<li><a href="#"></a></li>
          </ul>
          <form class="navbar-form navbar-right" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="get">
            <input type="text" name="searchfield" class="form-control" placeholder="Search...">
			<input type="hidden" name="do" value="insert">      <!--          von mir hinzugefügt         -->
		  </form>
        </div>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active"><a href="#">Übersicht <span class="sr-only">(current)</span></a></li>
            <li><a href="upload.html">Upload</a></li>
            <li><a href="Download.html">Download</a></li>
			<li><a href="addalbum.php">Album manuell hinzufügen</a></li>
			<li><a href="modsong.php">Lied ändern/löschen</a></li>
          </ul>
         
		 </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Dashboard</h1>

          <div class="row placeholders">
            <div class="col-xs-6 col-sm-3 placeholder">
              <img src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" width="200" height="200" class="img-responsive" alt="Generic placeholder thumbnail">
              <h4>Künster</h4>
              <span class="text-muted">Something else</span>
            </div>
            <div class="col-xs-6 col-sm-3 placeholder">
              <img src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" width="200" height="200" class="img-responsive" alt="Generic placeholder thumbnail">
              <h4>Alben</h4>
              <span class="text-muted">Something else</span>
            </div>
            <div class="col-xs-6 col-sm-3 placeholder">
              <img src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" width="200" height="200" class="img-responsive" alt="Generic placeholder thumbnail">
              <h4>Songs</h4>
              <span class="text-muted">Something else</span>
            </div>
            <div class="col-xs-6 col-sm-3 placeholder">
              <img src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" width="200" height="200" class="img-responsive" alt="Generic placeholder thumbnail">
              <h4>Genres</h4>
              <span class="text-muted">Something else</span>
            </div>
          </div>

          <h2 class="sub-header">Musikauswahl</h2>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Künstler</th>
                  <th>Album</th>
                  <th>Song</th>
                 </tr>
              </thead>
              <tbody>
<?php
	// Implicit declaration of constant (vermeidet Fehlermeldung)
	
	if($connection = new MongoDB\Client("mongodb://localhost:27017"))
	{
		echo "Connected Successfully<br><br>";
	}

$searchterm = "";

$counter = 0;

if (isset($_REQUEST["do"]) && $_REQUEST["do"] == "insert")
{
	$searchterm = $_REQUEST["searchfield"];
}

// select a database
	$db = $connection->musicmanager;
	// select a collection 
	$collection = $db->songs;	
	
$criteria = array();
//returns a cursor for the search results
$cursor = $collection->find($criteria);

// iterate through the results
foreach ($cursor as $row)
{
	if ($row[Kuenstlername] != "") $kuenstlerarray[$counter] = $row[Kuenstlername];
	if ($row[Albumtitel] != "") $albumarray[$counter] = $row[Albumtitel];
	if ($row[Liedname] != "") $songsarray[$counter] = $row[Liedname];
	
	$counter++;
}

$countermax = $counter;

for ($counter = 0; $counter <= $countermax; $counter++) //arrays ausgeben
{
	echo "<tr>";

	echo "<td>";
	if ($kuenstlerarray[$counter] != "")
	{
		echo $kuenstlerarray[$counter];
	}
	echo "</td>";

	echo "<td>";
	if ($albumarray[$counter] != "")
	{
		echo $albumarray[$counter];
	}
	echo "</td>";

	echo "<td>";
	if ($songsarray[$counter] != "")
	{
		echo $songsarray[$counter];
	}
	echo "</td>";
	
	echo "</tr>";
}


	
?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

                                                                     <!--                                      -->
	
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="js/holder.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
